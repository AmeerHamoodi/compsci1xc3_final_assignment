var searchData=
[
  ['math101_20statistics_20code_13',['MATH101 statistics code',['../index.html',1,'']]],
  ['main_14',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_15',['main.c',['../main_8c.html',1,'']]]
];
