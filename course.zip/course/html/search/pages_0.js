var searchData=
[
  ['math101_20statistics_20code_51',['MATH101 statistics code',['../index.html',1,'']]]
];
