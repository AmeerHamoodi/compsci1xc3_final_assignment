var searchData=
[
  ['_5fcourse_26',['_course',['../struct__course.html',1,'']]],
  ['_5fstudent_27',['_student',['../struct__student.html',1,'']]]
];
